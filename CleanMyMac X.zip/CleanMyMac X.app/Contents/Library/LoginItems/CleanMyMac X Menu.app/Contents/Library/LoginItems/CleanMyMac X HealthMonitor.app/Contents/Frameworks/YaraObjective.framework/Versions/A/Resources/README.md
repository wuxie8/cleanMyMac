# YaraObjective

**Yara** is a syntax for describing different rules to match strings, files or processes. In some sense it is something like regular expressions, but even more flexible.

It was originally developed by Victor Alvarez of Virustotal. It's main purpose is to match malware files.

The framework is a wrapper around [VirusTotal's Yara engine](https://github.com/VirusTotal/yara).

## Example usage

```objective-c
@import YaraObjective;

YRDetector *detector = [YRDetector new];
NSString *rules = ... // yara rules text
NSURL *fileToScan = // URL of the file
[detector registerRules:rules withCategoryName:nil externalVariables:@[]];
NSArray<YRRule *> *matches = [detector matchesInFile:fileToScan 
                                    ruleCategoryName:nil 
                                    shouldReturnAllMatches:NO 
                                    temporaryExternalVariables:@[]];
for (YRRule *match in matches)
{
    // do sth with matched rules
}

```

Example rules file:

```
rule ExampleRule0 : tag1 tag2 tag3
{
    meta:
        metadata_string = "Rule0 string metadata"
        metadata_int = 1000
        metadata_bool = true
    
    strings:
        $my_text_string = "surprise"

    condition:
        $my_text_string
}
```
